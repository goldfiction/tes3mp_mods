TES3MP Credits
==============

C++ programmers
---------------

    David Cernat - World, NPC & quest sync, player sync improvements, state saving & loading, extensive scripting
    Stanislav Zhukov (Koncord) - Foundation for networking & scripting systems, player sync, server browser & master server


Deployment scripts
------------------

    Grim Kriegor


Community administrators
------------------------

    Volk Milit (Ja'Virr-Dar)
    Testman


Community moderators
--------------------

    Learwolf
    Michael Fitzmayer (mupf)
    Nac
    NicholasAH
    Shnatsel
    Snapjaw


Art
---

    Texafornian - TES3MP logo


Super special thanks
--------------------

    Alexander Ovsyannikov
    Bret Curtis (psi29a)
    Gabriel Pascu (iGrebla)
    greetasdf
    Jason Ginther
    Learwolf
    Marc Zinnschlag (Zini)
    Mitch (Zaberius)
    scrawl
    Testman


Special thanks
--------------

    Aesylwinn
    Boyos
    Brandon Guffey
    Caledonii
    Camul
    David Wery
    DestinedToDie
    Donovan Ando
    DrunkenMonk
    Gluka
    Goodevil
    Ignatious
    James Wards of Gore Corps LAN Club (gorecorps.co.nz)
    Jeff Russell
    Jeremiah
    Kyle Willey of Loreshaper Games (steempeak.com/@loreshapergames)
    Lewis Sadlier
    Luc Keating
    Mark Epstein aka StirlizZ
    Michael Zagar (Zoops)
    Nkfree
    Olaxan
    ppsychrite
    Rhiyo
    Ryan Gage
    Scorcio
    Simon Nemes
    Snorkel the Dolphin
    Swims-in-Shadows aka StrayHALO_MAN
    Texafornian
    Thrud
    Zach Wild
    Zaphida
    All the developers of OpenMW for creating an amazing open source project

