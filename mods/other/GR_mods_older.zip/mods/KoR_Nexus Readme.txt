KoR_Nexus v2.3beta by KoRRoDEAD


Adds a new interior cell with vast transporting services and special merchants and a Female Khajiit Companian (Based on Grumpy's companion v3.1)
-----

The only requirements i'm aware that this will need is

Morrowind
Tribunal
Bloodmoon

------

This is the first Morrowind mod (by me) that i have deemed good enough to release to the public.

----

Contents


1 Companian called Mai (located in Seyda Neen)
She can transport you directly to "The Nexus" (new cell)

In this cell you will find

13 new NPC's entitled "Guides"
Each dressed to suit the kinds of places they can take you to.
Example: Ashlander Guide is dressed in Chitin Armor and can take you to the 4 Ashlander Tribe Camps.
Example: Hlaalu Guide is dressed like a Hlaalu guard and can take you to the Hlaalu settlements ie. Balmora, Suran, Dren Plantation and Odai Plateau (where you get your manor)

(i've covered pretty much all the civilized locations)


11 special Creature Merchants who all trade in different goods.

----

I currently have only added some very minor dialogue but have plans for making it more indepth.

----

As a closing note, this is still a Work In Progress, which i plan on improving as my modding skills increase. I'm learning as i go.

If you find you like this mod or would like to adapt it, expand on it however you like, that is fine by me. 
But remember i WILL be updating it frequently until i'm completely happy with it.
Just make sure you give credit where it's due. 
Both to Grumpy and Emma for the Companian Base which i built Mai with, and to me for setting up the initial concept of this mod.

Also if there are any glaringly obvious cockups i've made please tell me as i'll be glad to fix them.

And if anyone has any suggestions that they would like to see in this mod that fits what i'm doing with it, please offer up and i shall see if i can do it.

----

Known Bugs need to be fixed:

-none at the moment

----

Things I plan on adding for future installments:

-Edited dialogue for Mai's Companion Commands.
-More unique dialogue and quests to the NPC's.
-A "Guest quarter's" to the nexus as somewhere to rest and store things. (possible quest pre-requisite)
-Permission from Westly to use some of his heads/hairs for my NPC's. (adding the meshes to my .rar so his headpack isn't a requirement.)
-A new NPC Healer to the imperial corner. (Intended to be more useful if you have the Healer mod where they offer the services advertised)

----

Version History

2.1 - 2.3 beta
-Added a light near the spriggan mechant "Twig" as she was very hard to see before.
-Added a constant Light Ability to the ghost merchant "Dumas" because he was also very hard to see.
-Replaced the swivelling door-to-nowhere at the entrance of "The Nexus" with a static.
-Fixed a few dialogue typos.
-Made some changes to "Annoying Adeth".
-Removed the clothes and weapons from "Mai" as immediate access to companian share was unbalancing. (She now asks for clothes)
-Altered the scroll of Necromancy to summon one of each undead, rather than 8 skeletons, as it only summons 1 on some computers.
-Altered the potion "Release your Demons" to have the right spell effect, i had accidentally selected the wrong one.
-Replaced another wobbling barrel with a static barrel.
-Fixed missing dialogue with "Fiddler" as in 2.0 he was non-interactive.
-Added some missing weapons to the NPCs in The Nexus. (Guards with fists aren't that scarey or lore friendly)



2.0 beta
-Removed dependancy on Westly's headpack by giving NPC's vanilla heads.
-Fixed floaters and bleeders.
-Fixed a few misplaced travel markers.
-Changed Mai from Thief to Slave.
-Renamed "Mai's Base" to "The Nexus"
-Adjusted AI so the creatures and guides will attack if you steal commit a crime in The Nexus.
-Adjusted the race and/or gender of some of the guides to make it more balanced yet still make sense.
-Added new Guide to Solstheim.
-Added generic greeting dialogue to the guides, explaining where they can take you.
-Added new dialogue to Mai and her master as a setup for any future quests i may add.
-Added 8 more creature merchants, each with their own use.
-Adjusted the lighting.
-Added some expensive "god items" to one of the vendors
-Added new room/area to the back of "The Nexus"

1.0
-Initial version requires Westly's master headpack.
-Adapted "Grumpy's Companion Project v3.1" to Female khajiit thief called Mai.
-Created new cell "Mai's Base"
-Created 12 npc's called "Guides" each transport you around Vvardenfell.
-Created 3 creature merchants.