*****************************************************************

An Elder Scrolls III Mod
Rare Spell Vendor (RSV)

v1.0.0
*****************************************************************



*****************************************************************

Index
1. About
2. Features
3. Changelog
4. Installation
5. Requirements
6. Compatibility
7. Credit
8. Permissions


*****************************************************************

     1. About

*****************************************************************

Elder Scrolls III: Morrowind has a great variety of spells and spell effects. However, there are several of spell effects that the player can never obtain. This mod adds a vendor where you can purchase spells that use them.

Not all these spells are useful, and not all of the effects are useful. But the point of this mod is simply to make them available. Not included are the Corprus Disease effect (for obvious reasons) and the Remove Curse effect, which will be the subject of a later mod.


*****************************************************************

     2. Features

*****************************************************************

Deminah R�zamen has been added to the Holamayan Monastery to sell the spells.

Spells
Damage to Sureflight
* Damage to Marksman 1-20pts for 1 sec on target, Cost: 6

Weakness to Blight Disease
* Weakness to Blight Disease 1-20pts for 10 secs on target, Cost: 32

Weakness to Normal Weapons
* Weakness to Normal Weapons 10pts for 5 secs on target, Cost: 8

Magicka Vortex
* Absorb Magicka 10pts for 5 secs on touch
* Stunted Magicka for 30 secs on touch
* Weakness to Magicka 25pts for 30 secs on touch, Cost: 113

Night Form
* Fortify Skill: Sneak 10pts for 10 secs on self
* Invisibility 10 secs on self
* Sun Damage 2pts for 50 secs on self, Cost: 20

Weakness to Corprus Disease
* Weakness to Corprus Disease 1-20pts for 10 secs on target, Cost: 32

Absorb Glib Speech
* Absorb Skill: Speechcraft 5-20pts for 30 secs on touch, Cost 38

Camp Magicka
* Restore Magicka 1pt for 120 secs on self, Cost 30

Restore Stolid Armor
* Restore Skill: Heavy Armor 5-20pts for 30 secs on self, Cost: 19

Blood Rage
* Fortify Attack: 20pts for 60 secs on self, Cost: 20

Faerie Form
* Fortify Maximum Magicka 0.6x INT for 60 secs on self, Cost: 72

Resist Normal Weapons
* Resist Normal Weapons 10pts for 5 secs on self, Cost: 13


*****************************************************************

     3. Changelog

*****************************************************************

v1.0.0
* Released.


*****************************************************************

     4. Installation

*****************************************************************

Download CBP with Nexus Mod Vortex, then enable.

Or:
1. Download the CBP file manually.
2. Then unzip the file.
3. Copy and paste RSV.ESP to your Morrowind Data Files Folder (e.g., C:\Program Files\Steam\steamapps\Common\Morrowind\Data Files).
4. Enable RSV.ESP with your mod manager.

A new game is highly recommended!


*****************************************************************

     5. Requirements

*****************************************************************

* Elder Scrolls III: Morrowind


*****************************************************************

     6. Compatibility

*****************************************************************

The Rare Spell Vendor should be compatible with any mod that does not modify the interior of the Holamayan Monastery. It will be compatible with all my mods that do not explicitly say otherwise, except for the balance mods it supersedes.


*****************************************************************

     7. Credits

*****************************************************************

* The Creators of Elder Scrolls Lore
* The Creators of Elder Scrolls III: Morrowind
* The Creators of Elder Scrolls Travels: Stormhold
* The Creators of Elder Scrolls IV: Oblivion: Spell Tomes


*****************************************************************

     8. Permissions

*****************************************************************

You are free to modify this mod without contacting me, in anyway, as long as it remains free. Just give credit to Trackah.


