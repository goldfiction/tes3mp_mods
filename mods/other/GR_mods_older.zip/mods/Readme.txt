-- ZIPPS FURNITURE STORE README --


 /===========\
{ Author/Info }
 \===========/
Zipp - Thanks a ton for trying out my mod! This is my first mod for any game, ever... so be gentle ;)

====================
This mod will allow you to buy furniture (misc items) from a newly added shop and drop them where ever you like!  You can drop then and pick them up as many times as you want from the menu.  When you're satisfied, close the menu and it will be "semi-locked in".  After you place the furniture you can place items directly on the furniture as you would with a regular static.  If you accidentally click on your furniture when you try to pick up an item that was sitting on it, (depending on if the menu is opened or closed) it will :

(menu closed) open a dialogue box to ask you if you meant to pick it up or if it was a slip of the finger.

(menu open) do nothing until you close the menu, at which point it will open a dialogue box to ask you if you meant to pick it up or if it was a slip of the finger.

** Beds will also give you the option to sleep of course.
====================


====================
I'm super OCD with certain things and in this game I feel like I need to collect everything.  I felt like the 'perfect house' didn't exist.  There are houses that I like but I don't like the way the furniture is set up.  All I wanted to do was move a bookcase and maybe add a couple more bookcases.  I couldn't find any such mod that accomplished my desires. That's why I decided to make this.  It suits my needs quite well and I hope others can benefit from it as too.
====================


====================
The following is funtionality from vanilla Morrowind (Not this mod) but I think it's useful in conjuction with this mod :

To clean up garbage statics (unmovable bones, useless boxes without lids, poorly placed bookcases, random dirt piles inside buildings), I just open the console > click on the static that I don't like > type "disable" (without the quotes) > hit enter > close the console > and poof it's gone.

** Note that sometimes you may have to use tcl to fly behind the static or get some other wierd angle to be able to select it.  (just type tcl in the console and hit enter.  When finished, open the colsole again, type tcl, and hit enter again)

To replace the static with the furniture of your choice, you'll have to find the furniture store ;)
====================


 /======\
{ Credit }
 \======/
If you use my mod in your mod or repost this somewhere, please remember to cite me.  Thanks!


 /================\
{ Conflicting Mods }
 \================/
I highly doubt it will conflict with anything.  Use this without fear.


 /===========\
{ Recommended }
 \===========/
Jakethesnake's Books Rotate - It allows you to organise books very nicely on your new movable bookshelves.  The version I downloaded 5.3 and I got it from this website : 

http://www.gamewatcher.com/mods/the-elder-scrolls-iii-morrowind-mod/books-rotate-5-3


 /============\
{ Installation }
 \============/
Simply unzip the RELEVANT .esp(s) to your <.../Morrowind/Data Files> directory.

If you DON'T have Tribunal, you'll only need the Morrowind ESP.

If you DO have Tribunal, you'll want BOTH.

When you start the Morrowind launcher, remember to enable the .esp(s) before you hit play!


 /=================\
{ Furniture Crafter }
 \=================/
Ya that's me... Just leave a message on the nexusmods file and I'll throw whatever you want into the mod provided I have a working mesh.  Basically any static object you see in-game can be added.  I would also be happy to add in custom meshes. Just let me know and I'll tell you how you can send your meshes to me.

If you feel like including an icon file that goes with your request, I would greatly appreciate it and it would save me some time.  If you don't know how to do it, you can learn how very quickly, very easily, and very free right here :

https://video.search.yahoo.com/yhs/search;_ylt=A0LEViMpM5VXwgQAJWYPxQt.;_ylu=X3oDMTByMjB0aG5zBGNvbG8DYmYxBHBvcwMxBHZ0aWQDBHNlYwNzYw--?p=How+To+Make+a+Morrowind+Dds+Icon&fr=yhs-avg-fh_lsonsw&hspart=avg&hsimp=yhs-fh_lsonsw#id=1&vid=d23aee61041a9c4685ad3fff8b6d60cd&action=view


 /==========\
{ In Closing }
 \==========/
Thanks again for giving my mod a shot!  If you like it, please don't forget to endorse me on the nexusmods website and tell your friends! =)