*****************************************************************
Blessings for Other Shrines
v0.6
*****************************************************************

Index
1. Description
2. Change Log
3. Requirements
4. Installation
5. Compatibility
6. Credit
7. Usage

*****************************************************************
1. Description
*****************************************************************

Allows you to pick a blessing from other pantheons for your 
character.

The Tribunal pantheon (and its saints) are the only pantheon in 
Morrowind that gives the player a blessing at its shrines for 
being a devout worshiper.  Why should they be the only one?

Also makes it so you can only join one religion at a time.

*****************************************************************
2. Change Log
*****************************************************************

v0.6
*Lady's Grace spell renamed Almalexia's Compassion
*Jaws of Akatosh added
*Breath of Arkay added
*Dibella's Kiss added
*Scales of Julianos added
*Kynareth's Way added
*Wisdom of Mara added
*Heart of Stendarr added
*Fist of Talos added
*Zenithar's Ear added
*Azura's Dawn added but not implemented
*Boethiah's Secret added but not implemented
*Web of Mephala added but not implemented
*Malacath's Oath added but not implemented
*Hist Bloom added but not implemented
*Gift of the All-Maker added but not implemented
*Imperial Cult altars Restore Attributes renamed Restore 
	Attributes and Skills
*Tribunal shrines Vivec's Mystery and Almsivi Restoration cost 
	the right amount
*Imperial Cult altars now give blessing option
*Imperial Cult and Tribunal Temple are mutually exclusive factions

*****************************************************************
3. Requirements
*****************************************************************

*Morrowind
*Bloodmoon

*****************************************************************
4. Installation
*****************************************************************

Unzip and drop the esp. file into Morrowind's Data Files folder.

*****************************************************************
5. Compatibility
*****************************************************************

Modifies the scripts that control the shrines.  It also adds a 
few new shrines to various place but they should not interfere 
with most mods.

*****************************************************************
6. Credit
*****************************************************************

The developers of Morrowind, Bloodmoon and the Construction Set

The developers of Daggerfall for inspiration for effects

The developers of Oblivion who came up with perfect names 
for the blessings of the Divines and inspiration for effects

The developers of Skyrim for inspiration for effects

*****************************************************************
7. Usage
*****************************************************************

Feel free to use and modify any part of this mod and distribute 
without cost.  Just please credit me, Trackah.

*****************************************************************