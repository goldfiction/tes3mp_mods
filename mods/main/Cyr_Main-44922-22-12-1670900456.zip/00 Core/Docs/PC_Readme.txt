PROVINCE: CYRODIIL README

====================================================
TABLE OF CONTENTS
====================================================

	I. INTRODUCTION
	II. INSTALLATION
		i. Requirements
		ii. Install Process
		iii. Registering Game BSA
		iv. Updating Save Games
	III. PLAYING PROVINCE: CYRODIIL
	IV. KNOWN ISSUES AND INCOMPATIBILITIES
		i. Known Bugs
		ii. Known Incompatibilities
	V. TROUBLESHOOTING
		i. Common Issues
		ii. Known Bugs
	VI. PROJECT STATUS
	VII. DISCLAIMER

====================================================
I. INTRODUCTION
====================================================

Province: Cyrodiil is a fan project for The Elder Scrolls III: Morrowind, aiming to create the province of Cyrodiil inside of the Morrowind engine and worldspace. The project exists under the umbrella of the Project Tamriel team, which includes Skyrim: Home of the Nords and other province mods.

The Cyrodiil we aim to make is our own interpretation, rather than a copy of Bethesda�s work in TES:4. Based on lore from the Pocket Guides to the Empire and other sources, we have based our creation on what you might expect from having played Morrowind rather than later games in the series.

====================================================
II INSTALLATION
====================================================

----------------------------
i. Requirements
----------------------------
Before installing Province: Cyrodiil, please ensure that you have the latest version of Morrowind (v 1.6820), including both Tribunal and Bloodmoon installed, as well as Tamriel_Data version v9.0 or higher. The Morrowind Code Patch is highly recommended for the vanilla engine. Other province projects, such as Tamriel Rebuilt, and Skyrim: Home of the Nords, are highly recommended. All three province projects are dependent on Tamriel_Data, and seek to offer an integrated and mutually consistent experience.
- Tamriel_Data: https://www.nexusmods.com/morrowind/mods/44537
- Morrowind Code Patch (MCP): https://www.nexusmods.com/morrowind/mods/19510
- Tamriel Rebuilt: https://www.nexusmods.com/morrowind/mods/42145
- Skyrim: Home of the Nords: https://www.nexusmods.com/morrowind/mods/44921

----------------------------
ii. Install Process
----------------------------
To install Province: Cyrodiil, simply extract the contents of the "00 Core" folder into your "Data Files� folder in your Morrowind directory. When prompted to merge folders, click Yes. If you have a previous version installed, be sure to overwrite all files.

----------------------------
iii. Registering Game BSA
----------------------------
If this is your first time installing Province: Cyrodiil, you will need to make a one-time edit to the Morrowind.ini file in the game directory, instructing the game to load our game assets. To do this, open the INI file in any text editor, and navigate to the [Archives] section of the INI. You should see a list of registered game archives from the Tribunal and Bloodmoon expansions. You must change your list to look like this:

[Archives]
Archive 0=Tribunal.bsa
Archive 1=Bloodmoon.bsa
Archive 2=PC_Data.bsa
Archive 3=TR_Data.bsa
Archive 4=Sky_Data.bsa

----------------------------
iv. Enabling Game Files
----------------------------
The final step before playing the new content is to ensure that the data files are enabled in Morrowind's Launcher. Simply launch Morrowind and ensure that Tamriel_Data.esm and Cyr_main.esm are ticked.

----------------------------
v. Updating Save Games (if using existing save with a previous version of TR): 
----------------------------
If you are updating Province: Cyrodiil, and intend on resuming play using an existing save-game, you must first run the file patcher contained in Tamriel_Data download and then undertake the additional steps outlined here (http://wiki.theassimilationlab.com/mmw/Wrye_Mash#Using_an_Updated_Version_of_a_Mod) to resolve any potential errors when using an old save-game on a newer version of Province: Cyrodiil. Please note, you will need to download and install the Wyre Mash utility to clean and repair your savegame using the method above as well as a Java Runtime Engine to use the file patcher.

====================================================
III. PLAYING PROVINCE: CYRODIIL
====================================================

All Province: Cyrodiil content will be accessible the moment you load a saved game, or start a new game.

----------------------------
i. Accessing the Landmass
----------------------------
Province: Cyrodiil is being developed starting from the west side of the landmass. As such, it is inadvisable to try and reach the playable content on foot - this could take a very long time. Players present on Vvardenfell can fast travel to the island of Stirk by taking a boat from the docks of Ebonheart. As more parts of the landmass are developed, more travel options will become available. 

====================================================
IV. KNOWN ISSUES AND INCOMPATIBILITIES
====================================================

----------------------------
i. Known Bugs
----------------------------
As Province: Cyrodiil is a work-in-progress, be aware that there will be bugs and inconsistencies in our content, especially with much of it being made before our current standards. The currently released worldmap consists only of the island of Stirk and the surrounding oceans, and any content here is subject to revision (especially dialogue and quests).

Map Cutoff: Users playing on the vanilla game engine may notice that the in-game map does not show any part of the Cyrodiil landmass. Sadly, the vanilla Morrowind engine is fixed on the island of Vvardenfell, making it impossible to see your location when visiting the mainland. At the moment, there is no way to remedy this, though you can use map objects sprinkled throughout the worldspace. If you are running an OpenMW game, this problem should not present itself.

Distant region crashes: As the western parts of Cyrodiil are very far away from the center of the Morrowind worldspace, certain engine instabilities are unavoidable. This may result in weird bugs or crashes. Installing the Morrowind Code Patch may alleviate some of these issues. The OpenMW engine should also not be plagued by these issues.

Incomplete or Missing Questlines: Since our project is still in its early stages, factions do not offer complete questlines. This will change as more guildhalls and places become available.

Unfinished Landmass: As of our latest release, a lot of Cyrodiil's landmass is still unfinished. Unfinished areas appear as a sudden end of the landscape east of our finished areas.  

Low FPS: Some of our older areas or assets were created with little regard to playability and optimization. Assets and areas marked as problematic will be updated in future releases. Please let us know if you encounter any such low-FPS areas.

----------------------------
ii. Known Incompatibilities
----------------------------
At the moment, no incompatibilities between Province: Cyrodiil and other mods are known to us.  

====================================================
V. TROUBLESHOOTING
====================================================

----------------------------
i. Common Issues
----------------------------
While playing Province: Cyrodiil, you may run into several problems. These are listed below.

Missing Resources: Users who fail to register the BSA correctly will often find that loading Province: Cyrodiil will result in a lot of "missing meshes/animation" error dialog messages popping up on load, some even fatal. Please double-check your Morrowind.ini file to ensure our Data Archive is registered properly, otherwise the game won't load. Such missing assets will show up in-game as large yellow exlamation boxes. 

Windows Vista and above: Users who play Morrowind on operating systems later than Windows Vista may find that despite their efforts, the game will still churn out missing mesh errors. This is a result of the User Account Controls that were introduced in these versions of Windows. Either disable UAC through the Control Panel, or install the game in a directory other than �Program Files�.

----------------------------
ii.Reporting Bugs
----------------------------
As Province: Cyrodiil is a work-in-progress, it is inevitable that one will discover bugs along the way. These can range from small issues such as placement errors (floating objects, bleeding objects), to more serious problems like broken quests, dialogue, and land tears. It is crucial to report these to us so that they may be fixed in subsequent updates. 

It is recommended that you use the game's built-in beta comment feature to report bugs. You must first define the Beta Comment file in your Morrowind.ini by searching for Beta Comment File= and simply type in the name of the text file after the = sign. When you find a bug in game, open the console using the (~) key, click on the object in question, and type 

bc "describe the bug"

... which will dump the output and object coordinates to the text file defined above. Repeat this procedure whenever you encounter a bug. You may then open the text file afterwards and copy its contents when you file a bug report, either on our forums, or our official thread on the Elder Scrolls forum.


====================================================
VI. PROJECT STATUS
====================================================
As of December 2022, the island of Stirk is in alpha stage and will be reworked to better mesh with the Gold Coast content on the mainland. We hope to present mod users a larger, more fully realized version of Cyrodiil soon.

====================================================
VI. DISCLAIMER
====================================================

Please credit the original authors first if the asset you want to use appears in this list (search using the corresponding Construction Set ID without suffix numbers); "edited" indicates that the meshes or textures of the original asset have been altered or compressed in PT.

This list is retroactively documented in 2017 and therefore prone to oversights. Should anyone find they have been omitted from this list, please let us know.

author:    Momo77
---------------------------------
added Feb 2012, from:     Momos Crane Resource - http://www.nexusmods.com/morrowind/mods/41074/?
IDs:    
	T_Com_SetHarbor_CraneLarge_01 # to # 03
	T_Com_SetHarbor_CraneMiddle_01 # to # 02
	T_Com_SetHarbor_CranePlatfL_01
	T_Com_SetHarbor_CranePlatfS_01
	T_Com_SetHarbor_CranePlatfVL_01
	T_Com_SetHarbor_CraneSmall_01
added Feb 2012, from:     Momos Fishery Resource - http://www.nexusmods.com/morrowind/mods/41173/?
IDs:    
	T_Com_SetHarbor_DipNet_01 # to # 02
	T_Com_SetHarbor_FishBeheaded_01 # to # 02
	T_Com_SetHarbor_FishHanging_01 # to # 02
	T_Com_SetHarbor_Fishnet_01 # to # 02
	T_Com_SetHarbor_FishTrap_01
	T_Com_SetHarbor_Rope_01

author:    Slartibartfast
---------------------------------
added Aug 2012, from:     Smith Shed Resource - http://www.nexusmods.com/morrowind/mods/42183/?
IDs:    
	T_Imp_SetMw_X_SmithShed_01
	T_Imp_SetNord_X_SmithShed_01
	T_Nor_SetSkaal_SmithShed_01

author:    t'nilc
---------------------------------
added Aug 2013, from:     Hookah - http://mw.modhistory.com/download-1-11970
IDs:    
	T_Rga_HookahApp_01 (edited)
	T_Rga_HookahFlavouredApp_01 (edited)

author:    Midgetalien
---------------------------------
added Aug 2013, from:     Stick Fences -     http://www.nexusmods.com/morrowind/mods/42471/?
IDs:    
	T_Com_Set_FenceBriar_01 # to # 03
added Dec 2013, from:    Goblin Shaman - http://mw.modhistory.com/download-44-13318
IDs:    
	T_Mw_Cre_GobShm_01 (edited)

author:    dongle
---------------------------------
added Jul 2014, from:     Elizabethan Galleon - http://mw.modhistory.com/download-44-2980
IDs:    
	T_Imp_SetHarbor_GalleonNavy_01 (edited)
	T_Imp_SetHarbor_GalleonInLow_01 (edited)
	T_Imp_SetHarbor_GalleonInUp_01 (edited)

author:    Detritus2004
---------------------------------
added Dec 2016, from:     Khajiit Faces v2.0 - http://mw.modhistory.com/download-43-3301
IDs:    
	T_B_Kha_HeadMaleTR_02 # to # 09 (edited)
	T_B_Kha_HeadFemTR_01 # to # 09 (edited)
	T_B_Kha_HairMaleTR_01 # to # 02

author:    Silaria
---------------------------------
added Dec 2016, from:     Sils Argonian Heads and Hair v1.1 - http://mw.modhistory.com/download-80-3324
IDs:    
	T_B_Arg_HeadMaleTR_02 # to # 07 (edited)
	T_B_Arg_HeadFemTR_01 # to # 06 (edited)
	T_B_Arg_HairMaleTR_01 # to # 07 (edited)
	T_B_Arg_HairFemTR_01 # to # 04 (edited)

author:    R-Zero
---------------------------------
added Mar 2017, from:     TR Silt Strider fix - http://www.nexusmods.com/morrowind/mods/43297/?
IDs:    
	T_Mw_Fau_Slstrid_01

author:    Alaisiagae
---------------------------------
added Jul 2017, from:     Imperial Silver Armor Resource - http://mw.modhistory.com/download-56-6598
IDs:    
	T_Imp_Silver_Boots_01 (edited)
    T_Imp_Silver_BracerL_01 (edited)
    T_Imp_Silver_BracerR_01 (edited)
    T_Imp_Silver_Greaves_01 (edited)
    T_Imp_Silver_PauldronL_01 (edited)
    T_Imp_Silver_PauldronR_01 (edited)
    
author:    YarYulme
---------------------------------
added Jan 2018, from:     Nif Resources - https://www.nexusmods.com/morrowind/mods/43064/?
IDs:    
	T_Imp_Uni_SwiftcutSaber

author:    Lochnarus
---------------------------------
added Jan 2018, from:     Elite Dark Brotherhood Helm v1.3 - http://mw.modhistory.com/download-80-7683
IDs:    
	T_De_UNI_PreyseekerHelm (edited)

author:    Antares
---------------------------------
added Jan 2018, from:     Undead: Arise From Death - http://mw.modhistory.com/download-55-15310
IDs:    
	T_Mw_Und_Mum_02 (edited)

author:    Lougian
---------------------------------
added Jan 2018, from:     Caverns Overhaul - https://www.nexusmods.com/morrowind/mods/42249/?
IDs:    
	T_Glb_Light_CaveRay01 # to # 12 (updated)

Province: Cyrodiil is a not-for-profit development team made up entirely of fans. We are not in any way, shape or form associated or affiliated with Bethesda Softworks�, Zenimax, or any other entity involved in Morrowind�s original development. The Elder Scrolls is a registered trademark of Bethesda Softworks. All additional content produced outside Bethesda Softworks and the TES Construction Set remains the intellectual property of its creators.

All rights to original game assets belong to Bethesda Softworks. Additional assets created for Province: Cyrodiil are the property of their creators first, and the organization second. The following resources should only be used in mods with a dependency on Tamriel_data: Khajiit subraces, Maormer race, Direnni Haunted Sound. All other assets are free to use and redistribute in other modifications provided that their original author (where applicable) or Tamriel Rebuilt are duly credited. 

The content of this archive is � Province: Cyrodiil Community 2001-2018.
http://project-tamriel.com

