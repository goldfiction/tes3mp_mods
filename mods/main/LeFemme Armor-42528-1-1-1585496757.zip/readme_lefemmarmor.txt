*****************************************************************

     The Elder Scrolls III
           MORROWIND: 
      LeFemm Armor Plugin 1.1
		
*****************************************************************

Index:
1. Installation
2. Playing the Plugin
3. Save Games
4. Updates



*****************************************************************

     1. INSTALLING THE PLUGIN

*****************************************************************

To install the plugin, unzip the files into the Morrowind/Data Files
directory. 

UPDATE: This plugin has been updated to version 1.2.0722 of Morrowind.
You will receive a master file/plugin incompatibility error when
run with prior versions, but the plugin will work correctly.


*****************************************************************

     2. PLAYING THE PLUGIN

*****************************************************************

From the Morrowind Launcher, select Data Files and check the box 
next to the lefemmarmor.esp file.

LeFemm(TM) armor, specially tailored for the ladies, is on sale at 
Fighters Guild in Vivec, from Sirollus Saccus in Ebonheart, the Redoran 
Vaults, and the lady smiths in Ald-ruhn, Sadrith Mora, and Ald Velothi.


*****************************************************************

     3. Save Games

*****************************************************************

Official Plugins will not invalidate your old saved games. If you save 
your game while this plugin is loaded, you may encounter error messages 
when you reload the saved game without the plugin. But you will be
able to continue on with the original game.

*****************************************************************

     4. Updates

*****************************************************************

Version 1.1
Conflict between TNT2-based video cards and the DDS art files fixed.