Main Quest Enhancers
A Mod By Trainwiz

v1.04 main changes /abot
This was originally for personal use, but as no official patch by original author at least for scripted leveled list problem exists yet...

- implemented WH-Reaper's fix: pickable items that had a script attached to them now do not get disabled while in player inventory
- addtolev/removefromlev now use unique leveled lists to avoid putting standard leveled lists in save disabling related leveled list merged changes in .esp
As usual, you need to regenerate your merged leveled list after changing/installing a mod.
- used some global variables test instead of GetJournalIndex
- used a global variable test instead of CellChanged to work better with door locks mods- moved/removed some clutter for better mod compatibility
- cleaned with tes3cmd + testool

Note: if you want the leveled list fix to work with a previous version save, you have to clean your save from scripted leveled lists written by previous mod version. If you are using Mash, try the "Repair All" option on your save. Or you can use Enchanted Editor, look inside Items Levelled and delete what starts with ex_



Description
__________________________________________
Ever thought that the main quest lacked a certain atmospheric quality? Didn't like that despite the ravings of the Sixth House getting stronger, you really didn't see them DO anything? Well MQE is my attempt to change that. It adds several plugins that will, as the main quest progresses, begin to show the collapse of Vvardenfell and the ever-increasing presence of the Sixth House. However if you destroy Dagoth Ur, all these changes will disappear.
The plugins are:

	Blighted Beasties: As Vivec's power wanes and the Ghostfence slowly starts to fail, some 6th house agents and monsters will escape past it. This makes it so that as time progresses, corprus monsters and lower ash monsters (such as zombies and slaves) start to appear outside of the Ghostfence.

	Crowd Control: As the main quest progresses, outlanders and dunmer alike will begin to take notice of the strange happenings around Vvardenfell, and react accordingly. Temples will begin to be crowded by the faithful and worried, infected will gather outside Tel Fyr, hoping for a cure, and some desperate souls will be waiting on docks for boats off the island. The Corpusarium will also become more crowded as well.

	Garrisoned Ghostgate: Worried about the lack of security, the houses will start increasing the number of armigers and ordinators at Ghostgate. With this plugin, as time progresses, more and more soldiers will arrive and make camp at Ghostgate.

	Imperial Intolerance: With this plugin, the Sixth House will begin to harass outlander institutions, such as the Legion, the Guilds, and the Imperial Cult. They will begin to grafitti their buildings, nail ravings to their doors, and generally try to scare the mongrel dogs of the empire.
	
	Sixth House Shrines: With this plugin, the followers of Dagoth will have more of a presence in the city. As time progresses, small, out of the way shrines will start popping up in larger towns and cities. The further you get in the main quest, the more these shrines will grow, and will eventually even gain raving preachers.

	Main Quest Enhancers: All the previous plugins combined into one.

Installation
_______________________________________
Both MQE_BlightedBeasties.esp and MQE_MainQuestEnhancers.esp require Tribunal, and will not work without it.
Extract the files anywhere you wish, then place each MQE plugin into your Morrowind/Data Files folder. Check whatever ones you want, or MQE_Mainquestenhanced.esp if you want all the changes.
This will require a save where the main quest is not complete, for obvious reasons. 

Compatibility
______________________________________
This mod will not be compatible with any mods that make significant landscape changes to Balmora, Ald-Ruhn, Sadrith Mora, and pretty much any town or temple in Morrowind. Past that, it has shown to be compatible with most other mods.
Known Incompatible Mods:
Morrowind Rebirth (For Garrisoned Ghostgate)

Misc Stuff
______________________________________
You're free to modify these mods however you wish. However if you plan to release a modified version, tell me! You don't need my permission, but I love seeing what people do with my work.
Questions, comments, concerns?
Email me at trainwiz@yahoo.com