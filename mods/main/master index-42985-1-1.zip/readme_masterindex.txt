*****************************************************************

     The Elder Scrolls III
           MORROWIND: 
      Master Index Plugin
		
*****************************************************************

Index:
1. Installation
2. Playing the Plugin
3. Save Games



*****************************************************************

     1. INSTALLING THE PLUGIN

*****************************************************************

To install the plugin, unzip the files into the Morrowind/Data Files
directory. 

UPDATE: This plugin has been updated to version 1.2.0722 of Morrowind.
You will receive a master file/plugin incompatibility error when
run with prior versions, however, it will run properly with the 1.1.0605 patch.
A sound bug exists when run with 1.0 release.


*****************************************************************

     2. PLAYING THE PLUGIN

*****************************************************************

From the Morrowind Launcher, select Data Files and check the box 
next to the master_index.esp file.

Folms Mirel tells you how to find the ten propylon indices. In return 
for all ten propylon indices, Folms Mirel offers to make you a single 
Master Index. With this Master Index, the player can travel to any 
propylon chamber, or return to Caldera Mages Guild from any propylon 
chamber.



*****************************************************************

     3. Save Games

*****************************************************************

Official Plugins will not invalidate your old saved games. If you save 
your game while this plugin is loaded, you may encounter error messages 
when you reload the saved game without the plugin. But, you will be
able to continue on with the original game.

