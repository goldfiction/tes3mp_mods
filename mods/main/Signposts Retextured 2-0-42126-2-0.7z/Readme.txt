Signposts Retextured 2.0

by PeterBitt
--------------------------




Yet another Signpost replacer! 

This makes the signs in Vvardenfell readable with vanilla friendly textures. 
No sign looks the same. Colors, font and resolution blend in with original MW graphics.

Signposts Retextured comes in two variants (1.2 and 2.0) and for each of them a "Tamriel Rebuilt: Sacred East" addon is available.





Installation:
-------------

1. copy the content of this archive in your Morrowind/Data Files folder
2. start the morrowind launcher, click "Data Files" and activate "PB_SignpostsRetextured.esp"
3. play the game

You dont need to start a new game, but make sure you have no other signpost replacer installed.

You can switch between 1.2 and 2.0 easily by replacing all files - the naming is exactly the same in both versions.



Changelog:
-------------

v2.0 - completely new design
v1.2 - new folder structure and file naming
v1.2 - less crazy font placement
v1.2 - fixed typo in "Dagon Fel" sign
v1.1 - fixed transparency errors on the textures (thanks to Tarius)
v1.1 - removed mouseover textbox when looking at the signs

v1.0 - first release